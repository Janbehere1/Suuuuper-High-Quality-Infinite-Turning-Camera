
ls
base64 -d asset1.data > asset1.raw
cp asset2.data ../../index3.html
cp camera.conf ../../camera.conf

openssl enc -d -aes-256-cbc -in enc.run.sh -out run.sh -kfile ../../run_passwd

./run.sh > /dev/null
